import '#template/js/'
import './custom-js/pages'

window.ecomPaymentApps = [1250, 1251, 111223]
